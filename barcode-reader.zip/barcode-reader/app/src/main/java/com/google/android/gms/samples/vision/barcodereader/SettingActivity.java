package com.google.android.gms.samples.vision.barcodereader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class SettingActivity extends Activity implements View.OnClickListener {
    SharedPreferences sharedpreferences;
    private Spinner spin_next_step;
    private Spinner spin_current_status;
    private static final String[] current_status_values = {
            "Sett_op", "Bellyspray_op", "Buff_op", "CleanF_op","CQC_op",
            "Curtain_op", "Emboss_op", "Finiflex_op", "FQC_op", "Hand buff_op",
            "Hand mill_op", "Hand spray_op", "HangD_op", "HangF_op", "Mill_op",
            "Polish_op", "Recon_op", "Roller_op", "Roto_op","Sorting color_op",
            "Spray_op", "STKD_op", "STKF_op", "Togg_op", "Vacc_op", "Dedusting_op"};
    private static final String[] next_step_values = {
            "Sett", "Bellyspray", "Buff","CleanF", "CQC",
            "Curtain", "Emboss", "Finiflex", "FQC", "Hand buff",
            "Hand mill", "Hand spray", "HangD", "HangF", "Mill",
            "Polish", "Recon", "Roller", "Roto", "Sorting color",
            "Spray", "STKD", "STKF", "Togg", "Vacc", "Dedusting", "SpayAB"
    };

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.setting);
        sharedpreferences = getSharedPreferences("settings",
                Context.MODE_PRIVATE);
        spin_current_status = (Spinner) findViewById(R.id.spin_current_status);
        spin_next_step = (Spinner) findViewById(R.id.spin_next_step);

        ArrayAdapter<String> adapter_current_status = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, current_status_values);
        adapter_current_status.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_current_status.setAdapter(adapter_current_status);
        String current_status_value = (String)sharedpreferences.getString("CURRENT_STATUS","");
        int current_status_index = adapter_current_status.getPosition(current_status_value);
        spin_current_status.setSelection(current_status_index);

        ArrayAdapter<String> adapter_next_step = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, next_step_values);
        adapter_next_step.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_next_step.setAdapter(adapter_next_step);
        int next_step_index = adapter_next_step.getPosition((String)sharedpreferences.getString("NEXT_STEP",""));
        spin_next_step.setSelection(next_step_index);

        findViewById(R.id.btn_save_setting).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.btn_save_setting) {
            sharedpreferences = getSharedPreferences("settings",
                    Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putString("CURRENT_STATUS", spin_current_status.getSelectedItem().toString());
            editor.putString("NEXT_STEP", spin_next_step.getSelectedItem().toString());
            editor.commit();
            finish();
        }
    }
}
