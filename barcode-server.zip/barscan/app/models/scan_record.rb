# frozen_string_literal: true

class ScanRecord < ApplicationRecord
end
