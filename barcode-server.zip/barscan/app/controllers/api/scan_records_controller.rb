# frozen_string_literal: true

class Api::ScanRecordsController < ApplicationController
  skip_before_action :verify_authenticity_token

  def create
    value = params['value']
    source = params['source']
    next_step = params['nextStep']

    order_info = Order.find_by_order_no(value.split('-').first);
    ScanRecord.create!(value: value,
      source: source,
      next_step: next_step,
      product_name: order_info&.product_name,
      color: order_info&.color,
      water_proof: order_info&.water_proof,
      vacuum_toggle: order_info&.vacuum_toggle,
      customer_shortname: order_info&.customer_shortname,
      end_user: order_info&.end_user,
      week_no: order_info&.week_no
      )
    head :created
  rescue Exception => e
    Rails.logger.info(e)
    head :bad_request
  end
end
