# frozen_string_literal: true

ActiveAdmin.register ScanRecord, as: 'ScanRecord' do
  # See permitted parameters documentation:
  # https://github.com/activeadmin/activeadmin/blob/master/docs/2-resource-customization.md#setting-up-strong-parameters
  #
  # permit_params :list, :of, :attributes, :on, :model
  #
  # or
  #
  # permit_params do
  #   permitted = [:permitted, :attributes]
  #   permitted << :other if params[:action] == 'create' && current_user.admin?
  #   permitted
  # end

  permit_params :value, :source

  index do
    selectable_column
    # id_column
    column 'Code' do |record|
      raw(
      "#{link_to record.value, "/admin/scan_records/#{record.id}"}"
      )
    end
    column 'Current Status' do |record|
      raw("#{sanitize(record.source)}")
    end
    column :next_step
    column :created_at
    column :product_name
    column :color
    column :customer_shortname
    column :end_user
    column :water_proof
    actions
  end

  filter :value, label: 'Code'
  filter :source, label: 'Current Status'
  filter :next_step
  filter :created_at
  filter :product_name, label: 'Product Name'
  filter :color, label: 'Color'
  filter :customer_shortname, label: 'Customer Shortname'
  filter :end_user, label: 'End User'

  form do |f|
    f.inputs do
      f.input :value
      f.input :source
    end
    f.actions
  end
end
