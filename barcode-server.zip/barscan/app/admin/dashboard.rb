require 'csv'

ActiveAdmin.register_page "Dashboard" do
  menu priority: 1, label: proc { I18n.t("active_admin.dashboard") }

  content title: proc { I18n.t("active_admin.dashboard") } do
    div class: "blank_slate_container", id: "dashboard_default_message" do
      span class: "blank_slate" do
        span I18n.t("active_admin.dashboard_welcome.welcome")
        small I18n.t("active_admin.dashboard_welcome.call_to_action")
      end
    end

    # Here is an example of a simple dashboard with columns and panels.
    #
    # columns do
    #   column do
    #     panel "Recent Posts" do
    #       ul do
    #         Post.recent(5).map do |post|
    #           li link_to(post.title, admin_post_path(post))
    #         end
    #       end
    #     end
    #   end

    #   column do
    #     panel "Info" do
    #       para "Welcome to ActiveAdmin."
    #     end
    #   end
    # end

    columns do
      column do
        panel 'CSV Uploads for Order data' do
          ul do
            render 'admin/dashboard/import_listings'
          end
        end
      end
    end
  end # content

  page_action :import_listings, method: :post do
    # set a breakpoint here to check if you receive the file inside params properly
    # CsvWorker.perform_async(params[:file].path)
    # do anything else you need and redirect as the last step
    Order.delete_all
    file = params[:file].path
    CSV.foreach(file, :headers => true, :encoding => 'ISO-8859-1') do |row|
      Order.create!(
        order_no: row[0],
        product_name: row[1],
        color: row[2],
        water_proof: row[3],
        vacuum_toggle: row[4],
        customer_shortname: row[5],
        end_user: row[6],
        week_no: row[7]
      )
    end

    redirect_to admin_dashboard_path
  end
end
