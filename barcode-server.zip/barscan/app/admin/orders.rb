ActiveAdmin.register Order, as: 'Order data' do
  permit_params :value, :source

  index do
    selectable_column
    # id_column
    column :order_no
    column :product_name
    column :color
    column :customer_shortname
    column :end_user
    column :water_proof
    actions
  end
end