class CreateScanRecords < ActiveRecord::Migration[5.2]
  def change
    create_table :scan_records do |t|
      t.string :value
      t.string :source

      t.timestamps
    end
  end
end
