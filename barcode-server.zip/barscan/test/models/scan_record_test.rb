require 'test_helper'

class ScanRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
